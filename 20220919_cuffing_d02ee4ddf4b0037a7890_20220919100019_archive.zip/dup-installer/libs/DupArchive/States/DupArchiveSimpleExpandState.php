<?php

/**
 *
 * @package Duplicator
 * @copyright (c) 2021, Snapcreek LLC
 *
 */

namespace Duplicator\Libs\DupArchive\States;

/**
 * Simple expand state
 */
class DupArchiveSimpleExpandState extends DupArchiveExpandState
{
    /**
     * Class constructor
     */
    public function __construct()
    {
    }

    /**
     * save function
     *
     * @return void
     */
    public function save()
    {
    }
}
